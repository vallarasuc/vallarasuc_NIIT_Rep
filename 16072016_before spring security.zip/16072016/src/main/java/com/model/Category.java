package com.model;
import javax.persistence.Column;
import org.hibernate.annotations.Entity;

@Entity
public class Category {
	@Column
	private String Code;
	
	@Column
	private String Name;
	
	@Column
	private String Price;
	
	@Column
	private String Edit;
	
	@Column
	private String Delete;

	public String getCode() {
		return Code;
	}

	public void setCode(String code) {
		Code = code;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	public String getEdit() {
		return Edit;
	}

	public void setEdit(String edit) {
		Edit = edit;
	}

	public String getDelete() {
		return Delete;
	}

	public void setDelete(String delete) {
		Delete = delete;
	}	

}
