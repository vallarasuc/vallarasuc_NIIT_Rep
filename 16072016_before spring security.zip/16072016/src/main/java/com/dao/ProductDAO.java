package com.dao;

import java.util.List;

import com.model.Products;

public interface ProductDAO {
void addproduct(Products p);
void viewproduct(String code);
void deleteproduct(Products p);
void editproduct(Products p);
List <Products>ViewProducts();
Products viewProductsby(String Code);

}
