package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.Products;
@Repository
public class ProductsDAOimpl implements ProductDAO{

	@Autowired
	SessionFactory sf;
	
	@Override
	public void addproduct(Products p) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(p);
		t.commit();	
	}

	@Override
	public void viewproduct(String code) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteproduct(Products p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void editproduct(Products p) {
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public List<Products> ViewProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Products viewProductsby(String Code) {
		// TODO Auto-generated method stub
		return null;
	}

}
