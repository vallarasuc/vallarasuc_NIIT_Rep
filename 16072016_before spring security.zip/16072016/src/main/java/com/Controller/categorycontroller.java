package com.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class categorycontroller {
	@RequestMapping("/Category")
	public String goCategory(){
		return "Category";
	}
	@RequestMapping("/EditCategory")
	public String goEditCategory(){
		return "editcategory";
	}
	@RequestMapping("/ViewCategory")
	public String goViewCategory(){
		return "viewcategory";
	}
	@RequestMapping("/DeleteCategory")
	public String goDeleteCategory(){
		return "deletecategory";
	}
}
