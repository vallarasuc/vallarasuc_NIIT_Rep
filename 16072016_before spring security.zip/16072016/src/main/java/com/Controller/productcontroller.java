package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dao.ProductsDAOimpl;
import com.model.Products;

@Controller
public class productcontroller {
	
	@Autowired
	ProductsDAOimpl pd;
	@RequestMapping("/Product")
	public String goProduct(){
		return "Product";
	}
	@RequestMapping("/AddProduct")
	public String goAddProduct(){
		Products p = new Products();
		p.setCode("1");
		p.setName("Vallu");
		p.setPrice("100");
		pd.addproduct(p);
		return "addproduct";
	}
	
	@RequestMapping("/EditProduct")
	public String goEditProduct(){
		return "editproduct";
	}
	@RequestMapping("/ViewProduct")
	public String goViewProduct(){
		return "viewproduct";
	}
	@RequestMapping("/DeleteProduct")
	public String goDeleteProduct(){
		return "deleteproduct";
	}
	@RequestMapping("/doEditProduct")
	public void doEditProduct(){
		System.out.println("Hello");
	}

}
