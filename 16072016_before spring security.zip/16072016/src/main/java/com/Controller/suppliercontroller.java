package com.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class suppliercontroller {
	@RequestMapping("/Supplier")
	public String goSupplier(){
		return "Supplier";
	}
	@RequestMapping("/EditSupplier")
	public String goEditSupplier(){
		return "editsupplier";
	}
	@RequestMapping("/ViewSupplier")
	public String goViewSupplier(){
		return "viewsupplier";
	}
	@RequestMapping("/DeleteSupplier")
	public String goDeleteSupplier(){
		return "deletesupplier";
	}
}
