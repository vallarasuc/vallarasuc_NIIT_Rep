package com.DAO;

import java.util.List;

import com.Model.Customer;

public interface CustomerDAO {
	void addCustomer(Customer c);
	void delCustomer(String emailId);
	void updCustomer(Customer c);
	List<Customer> viewCustomer();
	Customer viewCustomerByEmail(String email);
}
