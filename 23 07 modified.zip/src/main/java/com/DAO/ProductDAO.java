package com.DAO;

import java.util.List;

import com.Model.ProductModel;

public interface ProductDAO { 
	void addProduct(ProductModel p);
    void viewProduct(String code );
    void deleteProduct(ProductModel p);
    void editProduct(ProductModel p);
    List<ProductModel>ViewProductModel();
    ProductModel viewProductby(String code);
}
