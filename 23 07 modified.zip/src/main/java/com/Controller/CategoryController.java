package com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.DAO.CategoryDAO;
import com.Model.Customer;
import com.Model.CategoryModel;
import com.google.gson.Gson;

@Controller
public class CategoryController {
	
	@Autowired
	CategoryDAO pd;
	
	@RequestMapping("/category")
	public String gocategory(){
		System.out.println("In category");
		return "category";
	}
	
	/*@RequestMapping("/viewCategory")
	public String goviewCategory(){
		return "viewCategory";
	}*/
	
	@RequestMapping("/viewcategory")
	public String doviewCategory(){
		/*List<CategoryModel> l=pd.ViewCategoryModel();
		Gson gson = new Gson();
        String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("Categorylist");
        modelandview.addObject("json",json);
		//System.out.println(json);
		return modelandview;*/
		return "redirect:/categorylist";
	}
	@RequestMapping("/createcategory")
	public String goaddCategory(){
		System.out.println("In Add Category");
		//CategoryModel p = new CategoryModel();
		/*
		p.setcode("4");
		p.setname("p2");
		pd.addCategory(p);
		*/
		return "addcategory";
	}
	
	@ModelAttribute("cat")
	public CategoryModel doit(){
		return new CategoryModel();
	}
	
	@RequestMapping(value="/savecategory", method=RequestMethod.POST)
	public String doSave(@ModelAttribute("cat")CategoryModel p){
		System.out.println("insaveCategory");
		pd.addCategory(p);
		return "redirect:/categorylist";
	}
	@RequestMapping("/categorylist")
	public ModelAndView goCategorylist(){
		List<CategoryModel> l=pd.ViewCategoryModel();
		Gson gson = new Gson();
        String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("categorylist");
        modelandview.addObject("json",l);
		//System.out.println(json);
		return modelandview;
	}
	@RequestMapping("/editcategory")
	public String goeditCategory(){
		return "editcategory";
	}
	@RequestMapping("/editcat/{code}")
	public ModelAndView doeditCategory(@PathVariable String code){
		CategoryModel q = pd.viewCategoryby(code);
		System.out.println("Object : "+q);
		ModelAndView modelandview = new ModelAndView("addcategory");
		modelandview.addObject("cat", q);
		return modelandview;
	}
	
	@RequestMapping("/delcat/{code}")
	public String godeleteCategory(@PathVariable String code){
		System.out.println("In Delete Category");
		CategoryModel q = pd.viewCategoryby(code);
		//p.getcode();
		pd.deleteCategory(q);
		//System.out.println(p.getcode());
		return "redirect:/categorylist";
	}
	@RequestMapping("/dodeleteCategory")
	public String dodeleteCategory(@ModelAttribute("Category")CategoryModel p){
		System.out.println("In Delete Category");
		pd.deleteCategory(p);
		System.out.println("deleted");
		return "categorylist";
}
}
