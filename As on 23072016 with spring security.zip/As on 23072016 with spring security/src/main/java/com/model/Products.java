package com.model;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Entity;


@Entity
public class Products {
	@Id
	@Column
	private int Code;
	
	@Column
	private String Name;
	
	@Column
	private int Price;
	
	@Column
	private int Qty;
	
	@Column
	private String Category;
	
	
	public int getQty() {
		return Qty;
	}

	public void setQty(int qty) {
		Qty = qty;
	}

	public int getCode() {
		return Code;
	}

	public void setCode(int code) {
		Code = code;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getPrice() {
		return Price;
	}

	public void setPrice(int price) {
		Price = price;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

}
