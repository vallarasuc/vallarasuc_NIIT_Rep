package com.model;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Entity;


@Entity
public class Customer {
	@Column
	private String fname;
	
	@Column
	private String lname;
	
	@Id
	@Column
	private String userid ;
	
	@Column
	private String emailID;
	
	@Column
	private String dateofbirth;
	
	@Column
	private String password;
	@Column
	private boolean enabled;
	@Column
	private String role;

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
