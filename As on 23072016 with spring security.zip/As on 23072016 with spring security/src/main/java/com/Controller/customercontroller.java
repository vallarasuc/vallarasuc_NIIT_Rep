package com.Controller;

import java.util.List;

//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
//import org.springframework.web.bind.WebDataBinder;
//import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.method.annotation.InitBinderDataBinderFactory;
import org.springframework.web.servlet.ModelAndView;

import com.dao.customerDAO;
import com.google.gson.Gson;
//import com.google.gson.Gson;
import com.model.Customer;

@Controller
public class customercontroller {
	
	@Autowired
	customerDAO pd;
	
	/*@InitBinder
	public void initBinder(WebDataBinder binder){
		binder.setDisallowedFields(new String[]{"Code"});
	}*/
	@RequestMapping("/addcustomer")
	public String goaddcustomer(@ModelAttribute("addcustomer")Customer p){
	//Category p = new Category();
		//p.setCode("1");
		//p.setName("Vallu");
		//p.setPrice("100");
		pd.addcustomer(p);
		ModelAndView modelandview = new ModelAndView();
		modelandview.addObject("SucessfullMessage", "Sucessfully Added the Category");
		return "redirect:/Login";
	}
	
	@RequestMapping("/Userlogin")
	public String dologin(@ModelAttribute("Userlogin") Customer user, BindingResult br){
		//Category p = new Category();
		//p.setCode("2");
		//p.setName("Vallu");
		//p.setPrice("100");
		//pd.addcategory(p);
		Customer c = pd.viewcustomerby(user.getUserid());
		//Gson gson = new Gson();
        //String json = gson.toJson(c);
       // ModelAndView modelandview = new ModelAndView("category");
        //modelandview.addObject("json",c);
		//System.out.println(json);
        String userpassword =c.getPassword(); 
        if(userpassword==user.getPassword()){
        	return "customerhome";
        }
        return "errorpage";
        
		//return "editcategory";
	}
	/*
	@RequestMapping("/editCat/{code}")
	public String doeditCategory(@PathVariable int code){
		Category q = pd.viewCategoryby(code);
		ModelAndView modelandview = new ModelAndView("category");
		modelandview.addObject("category",q);
		return "redirect:/category";
	}
	@RequestMapping("/delCat")
	public String goDeleteCategory(){
		return "deletecategory";
	}
	@RequestMapping("delCat/{code}")
	public String doDeleteCategory(@ModelAttribute("AddCategory")Category p){
		pd.deletecategory(p);
		return "redirect:/category";
	}*/
}
