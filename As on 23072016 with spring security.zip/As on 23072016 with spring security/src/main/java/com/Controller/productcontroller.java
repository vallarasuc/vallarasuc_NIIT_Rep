package com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.method.annotation.InitBinderDataBinderFactory;
import org.springframework.web.servlet.ModelAndView;

import com.dao.ProductDAO;
import com.google.gson.Gson;
import com.model.Products;

@Controller
public class productcontroller {
	
	@Autowired
	ProductDAO pd;
	
	/*@InitBinder
	public void initBinder(WebDataBinder binder){
		binder.setDisallowedFields(new String[]{"Code"});
	}*/
	@RequestMapping("/addproduct")
	public String goAddProduct(@ModelAttribute("AddProduct")Products p){
	//Products p = new Products();
		//p.setCode("1");
		//p.setName("Vallu");
		//p.setPrice("100");
		pd.addproduct(p);
		ModelAndView modelandview = new ModelAndView();
		modelandview.addObject("SucessfullMessage", "Sucessfully Added the Product");
		return "redirect:/product";
	}
	
	@RequestMapping("/product")
	public ModelAndView goProduct(){
		//Products p = new Products();
		//p.setCode("2");
		//p.setName("Vallu");
		//p.setPrice("100");
		//pd.addproduct(p);
		List<Products> l=pd.ViewProducts();
		Gson gson = new Gson();
        String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("product");
        modelandview.addObject("json",l);
		//System.out.println(json);
		return modelandview;
		//return "editproduct";
	}
	@RequestMapping("/editPrd/{code}")
	public ModelAndView doeditProduct(@PathVariable int code){
		Products q = pd.viewProductsby(code);
		ModelAndView modelandview = new ModelAndView("product");
		modelandview.addObject("product",q);
		return modelandview;
	}
	@RequestMapping("/delPrd")
	public String goDeleteProduct(){
		return "deleteproduct";
	}
	@RequestMapping("delPrd/{code}")
	public String doDeleteProduct(@ModelAttribute("AddProduct")Products p){
		pd.deleteproduct(p);
		return "redirect:/product";
	}
}
