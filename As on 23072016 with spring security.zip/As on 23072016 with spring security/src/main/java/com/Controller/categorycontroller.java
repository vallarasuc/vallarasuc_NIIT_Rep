package com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.method.annotation.InitBinderDataBinderFactory;
import org.springframework.web.servlet.ModelAndView;

import com.dao.CategoryDAO;
import com.google.gson.Gson;
import com.model.Category;

@Controller
public class categorycontroller {
	
	@Autowired
	CategoryDAO pd;
	
	/*@InitBinder
	public void initBinder(WebDataBinder binder){
		binder.setDisallowedFields(new String[]{"Code"});
	}*/
	@RequestMapping("/addcategory")
	public ModelAndView goAddCategory(@ModelAttribute("AddCategory")Category p){
	//Category p = new Category();
		//p.setCode("1");
		//p.setName("Vallu");
		//p.setPrice("100");
		pd.addcategory(p);
		ModelAndView modelandview = new ModelAndView();
		modelandview.addObject("SucessfullMessage", "Sucessfully Added the Category");
		return modelandview;
	}
	
	@RequestMapping("/category")
	public ModelAndView goCategory(){
		//Category p = new Category();
		//p.setCode("2");
		//p.setName("Vallu");
		//p.setPrice("100");
		//pd.addcategory(p);
		List<Category> l=pd.ViewCategory();
		Gson gson = new Gson();
        String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("category");
        modelandview.addObject("json",l);
		//System.out.println(json);
		return modelandview;
		//return "editcategory";
	}
	@RequestMapping("/editCat/{code}")
	public String doeditCategory(@PathVariable int code){
		Category q = pd.viewCategoryby(code);
		ModelAndView modelandview = new ModelAndView("category");
		modelandview.addObject("category",q);
		return "redirect:/category";
	}
	@RequestMapping("/delCat")
	public String goDeleteCategory(){
		return "deletecategory";
	}
	@RequestMapping("delCat/{code}")
	public String doDeleteCategory(@ModelAttribute("AddCategory")Category p){
		pd.deletecategory(p);
		return "redirect:/category";
	}
}
