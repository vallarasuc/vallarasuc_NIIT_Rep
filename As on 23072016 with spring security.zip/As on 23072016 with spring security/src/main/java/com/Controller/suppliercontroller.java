package com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.method.annotation.InitBinderDataBinderFactory;
import org.springframework.web.servlet.ModelAndView;

import com.dao.SupplierDAO;
import com.google.gson.Gson;
import com.model.Suppliers;

@Controller
public class suppliercontroller {
	
	@Autowired
	SupplierDAO pd;
	
	/*@InitBinder
	public void initBinder(WebDataBinder binder){
		binder.setDisallowedFields(new String[]{"Code"});
	}*/
	@RequestMapping("/addsuppiler")
	public String goAddSupplier(@ModelAttribute("AddSupplier")Suppliers p){
	//Suppliers p = new Suppliers();
		//p.setCode("1");
		//p.setName("Vallu");
		//p.setPrice("100");
		pd.addsupplier(p);
		ModelAndView modelandview = new ModelAndView();
		modelandview.addObject("SucessfullMessage", "Sucessfully Added the Supplier");
		return "redirect:/supplier";
	}
	
	@RequestMapping("/supplier")
	public ModelAndView goSupplier(){
		//Suppliers p = new Suppliers();
		//p.setCode("2");
		//p.setName("Vallu");
		//p.setPrice("100");
		//pd.addsupplier(p);
		List<Suppliers> l=pd.ViewSuppliers();
		Gson gson = new Gson();
        String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("supplier");
        modelandview.addObject("json",l);
		//System.out.println(json);
		return modelandview;
		//return "editsupplier";
	}
	@RequestMapping("/editSup/{code}")
	public ModelAndView doeditSupplier(@PathVariable int code){
		Suppliers q = pd.viewSuppliersby(code);
		ModelAndView modelandview = new ModelAndView("supplier");
		modelandview.addObject("supplier",q);
		return modelandview;
	}
	@RequestMapping("/delSup")
	public String goDeleteSupplier(){
		return "deletesupplier";
	}
	@RequestMapping("delSup/{code}")
	public String doDeleteSupplier(@ModelAttribute("AddSupplier")Suppliers p){
		pd.deletesupplier(p);
		return "redirect:/supplier";
	}
}
