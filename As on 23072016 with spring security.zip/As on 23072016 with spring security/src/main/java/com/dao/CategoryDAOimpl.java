package com.dao;

import java.util.List;

import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
//import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.model.Category;
@Repository
@Transactional
public class CategoryDAOimpl implements CategoryDAO{

	@Autowired
	SessionFactory sf;
	//Session s = sf.openSession();
	@Override
	public void addcategory(Category p) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.saveOrUpdate(p);
		t.commit();	
	}

	@Override
	public void viewcategory(int code) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void deletecategory(Category p) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.delete(p);
		t.commit();	
		
	}

	@Override
	public void editcategory(Category p) {
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public List<Category> ViewCategory() {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		 Transaction t = s.beginTransaction();
		 List<Category> l = s.createCriteria(Category.class).list();
		t.commit();
		return l;
		//return null;
	}

	@Override
	public Category viewCategoryby(int Code) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		 Transaction t = s.beginTransaction();
		 Category p = (Category)s.load(Category.class, Code);
		 t.commit();
		return p;
	}

}
