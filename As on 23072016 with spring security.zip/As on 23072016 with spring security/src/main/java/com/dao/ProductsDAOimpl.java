package com.dao;

import java.util.List;

import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
//import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.model.Products;
@Repository
@Transactional
public class ProductsDAOimpl implements ProductDAO{

	@Autowired
	SessionFactory sf;
	//Session s = sf.openSession();
	@Override
	public void addproduct(Products p) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.saveOrUpdate(p);
		t.commit();	
	}

	@Override
	public void viewproduct(int code) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void deleteproduct(Products p) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.delete(p);
		t.commit();	
		
	}

	@Override
	public void editproduct(Products p) {
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public List<Products> ViewProducts() {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		 Transaction t = s.beginTransaction();
		 List<Products> l = s.createCriteria(Products.class).list();
		t.commit();
		return l;
		//return null;
	}

	@Override
	public Products viewProductsby(int Code) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		 Transaction t = s.beginTransaction();
		 Products p = (Products)s.load(Products.class, Code);
		 t.commit();
		return p;
	}

}
