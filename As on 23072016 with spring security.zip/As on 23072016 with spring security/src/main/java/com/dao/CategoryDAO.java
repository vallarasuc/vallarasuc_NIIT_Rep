package com.dao;

import java.util.List;

import com.model.Category;

public interface CategoryDAO {
void addcategory(Category p);
void viewcategory(int code);
void deletecategory(Category p);
void editcategory(Category p);
List <Category>ViewCategory();
Category viewCategoryby(int Code);
}
