package com.dao;

import java.util.List;

import com.model.Suppliers;

public interface SupplierDAO {
void addsupplier(Suppliers p);
void viewsupplier(int code);
void deletesupplier(Suppliers p);
void editsupplier(Suppliers p);
List <Suppliers>ViewSuppliers();
Suppliers viewSuppliersby(int Code);
}
