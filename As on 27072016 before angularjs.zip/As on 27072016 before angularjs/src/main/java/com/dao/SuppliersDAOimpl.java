package com.dao;

import java.util.List;

import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
//import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.model.Suppliers;
@Repository
@Transactional
public class SuppliersDAOimpl implements SupplierDAO{

	@Autowired
	SessionFactory sf;
	//Session s = sf.openSession();
	//@Override
	public void addsupplier(Suppliers p) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.saveOrUpdate(p);
		t.commit();	
	}

	//@Override
	public void viewsupplier(int code) {
		// TODO Auto-generated method stub
		
	}
	
	//@Override
	public void deletesupplier(Suppliers p) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.delete(p);
		t.commit();	
		
	}

	//@Override
	public void editsupplier(Suppliers p) {
		// TODO Auto-generated method stub
		
		
	}

	//@Override
	public List<Suppliers> ViewSuppliers() {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		 Transaction t = s.beginTransaction();
		 List<Suppliers> l = s.createCriteria(Suppliers.class).list();
		t.commit();
		return l;
		//return null;
	}

	//@Override
	public Suppliers viewSuppliersby(int Code) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		 Transaction t = s.beginTransaction();
		 Suppliers p = (Suppliers)s.load(Suppliers.class, Code);
		 t.commit();
		return p;
	}

}
