package com.dao;

import java.util.List;

import com.model.Customer;

public interface customerDAO {
	void addcustomer(Customer p);
	List <Customer>viewcustomer();
	Customer viewcustomerby(String userid);

}
