package com.model;

import javax.persistence.Column;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.Entity;


@Entity
public class Suppliers {
	@Id
	@Column
	private int Code;
	
	@Column
	@NotEmpty
	private String Name;
	
	/*@Column
	 @NotEmpty
	private String Category;
	*/
	public int getCode() {
		return Code;
	}

	public void setCode(int code) {
		Code = code;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
/*
	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}
*/
}
