package com.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Entity;


@Entity
public class Customer {
	@Column
	@NotEmpty(message = "Please Enter Your first Name")
	private String fname;
	
	@Column
	@NotEmpty(message="Please enter your last Name")
	private String lname;
	
	@Id
	@Column
	@NotEmpty(message="Please enter the userid")
	private String userid ;
	
	@Column
	@Email
	@NotEmpty(message="Please enter the emailID")
	private String emailID;
	
	@Column
	@NotEmpty(message="Please enter the Date of Birth")
	private String dateofbirth;
	
	@Column
	@NotEmpty(message="Please enter the Date of Password")
	
	private String password;
	@Column
	private boolean enabled;
	@Column
	private String role;

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
