package com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dao.SupplierDAO;
import com.google.gson.Gson;
import com.model.Category;
import com.model.Suppliers;

@Controller
public class suppliercontroller {
	
	@Autowired
	SupplierDAO pd;
	
	/*@InitBinder
	public void initBinder(WebDataBinder binder){
		binder.setDisallowedFields(new String[]{"Code"});
	}*/
	@RequestMapping("/admin/addsuppiler")
	public String goAddSupplier(@ModelAttribute("AddSupplier")Suppliers p){
		pd.addsupplier(p);
		ModelAndView modelandview = new ModelAndView("/web/admin/supplier");
		modelandview.addObject("SucessfullMessage", "Sucessfully Added the Supplier");
		return "redirect:/admin/supplier";
	}
	
	@RequestMapping("/admin/supplier")
	public ModelAndView goSupplier(){
		//Suppliers p = new Suppliers();
		//p.setCode("2");
		//p.setName("Vallu");
		//p.setPrice("100");
		//pd.addsupplier(p);
		List<Suppliers> l=pd.ViewSuppliers();
		Gson gson = new Gson();
        String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("/web/admin/supplier");
        modelandview.addObject("json",l);
		//System.out.println(json);
		return modelandview;
		//return "editsupplier";
	}
	@RequestMapping("/user/supplier")
	public ModelAndView gocustCategory(){
		//Category p = new Category();
		//p.setCode("2");
		//p.setName("Vallu");
		//p.setPrice("100");
		//pd.addcategory(p);
		List<Suppliers> l=pd.ViewSuppliers();
		Gson gson = new Gson();
       String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("web/custsupplier");
       modelandview.addObject("json",l);
		System.out.println(json);
		return modelandview;
		//return "editcategory";
	}
	
	@RequestMapping("/admin/editSup/{code}")
	public ModelAndView doeditSupplier(@PathVariable int code){
		Suppliers q = pd.viewSuppliersby(code);
		ModelAndView modelandview = new ModelAndView("/web/admin/supplier");
		List<Suppliers> l=pd.ViewSuppliers();
		modelandview.addObject("json",l);
		modelandview.addObject("supplier",q);
		return modelandview;
	}
	@RequestMapping("/admin/delSup/{code}")
	public String doDeleteSupplier(@ModelAttribute("AddSupplier")Suppliers p){
		pd.deletesupplier(p);
		return "redirect:/admin/supplier";
	}
	@RequestMapping("/web/supplier")
	public ModelAndView gowebCategory(){
		//Category p = new Category();
		//p.setCode("2");
		//p.setName("Vallu");
		//p.setPrice("100");
		//pd.addcategory(p);
		List<Suppliers> l=pd.ViewSuppliers();
		Gson gson = new Gson();
       String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("web/supplier");
       modelandview.addObject("json",l);
		System.out.println(json);
		return modelandview;
		//return "editcategory";
	}
}
