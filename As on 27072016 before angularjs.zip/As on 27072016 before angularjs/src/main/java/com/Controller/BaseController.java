package com.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.model.Customer;

@Controller
public class BaseController {

	@RequestMapping("/")
	public String goMenu(){
		return "web/index";
	}
	@RequestMapping("/web/about")
	public String goabout(){
		return "web/about";
	}
	@RequestMapping("/web/Login")
	public String goLogin(){
		return "web/Loginpage";		
	}
	@ModelAttribute("addcus")
	public Customer domodelandview(){
		return new Customer();
	}
	
	@RequestMapping("/web/Register")
	public String goRegister(){
		return "web/register";
	}
	@RequestMapping("/web/error")
	public String goerror(){
		return "web/register";
	}
	@RequestMapping("/web/admin/login")
	public String goadmin(){
		return "web/admin";
	}
	@RequestMapping("/web/user/Login")
	public String gouser(HttpServletRequest request, HttpServletResponse response){
		System.out.println(request.isUserInRole("ROLE_USER"));
		/*if (request.isUserInRole("ROLE_USER"))
		{
			return "web/custindex";	
		}
		else {
			return "web/admin";
		}*/
		return "web/custindex";
	}

	@RequestMapping("/web/Loginpage")
	public String gofinduser(HttpServletRequest request, HttpServletResponse response){
		/*if (request.isUserInRole("ROLE_USER"))
		{
			return "web/custindex";	
		}
		else {
			return "web/admin";
		}*/
		return "web/Loginpage";

	}
	
	@RequestMapping("/web/user/home")
	public String gouserhome(){
		return "web/userhome";
	}
	@RequestMapping("/web/user/userhome")
	public String gouserHome(){
		return "web/custindex";
	}
	@RequestMapping("/web/admin")
	public String goadminhome(){
		return "web/admin";
	}
	@RequestMapping("/web/admin/addadmin")
	public String goadminregister(){
		return "web/admin/adminregister";
	}
	
	@RequestMapping("/403")
	public String go403(){
		return "web/index";
	}
	

}
