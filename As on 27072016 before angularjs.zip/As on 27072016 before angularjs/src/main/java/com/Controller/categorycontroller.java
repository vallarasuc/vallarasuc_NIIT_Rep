package com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.method.annotation.InitBinderDataBinderFactory;
import org.springframework.web.servlet.ModelAndView;

import com.dao.CategoryDAO;
import com.google.gson.Gson;
import com.model.Category;

@Controller
public class categorycontroller {
	
	@Autowired
	CategoryDAO pd;
	
	/*@InitBinder
	public void initBinder(WebDataBinder binder){
		binder.setDisallowedFields(new String[]{"Code"});
	}*/
	@RequestMapping("/admin/addcategory")
	public String goAddCategory(@ModelAttribute("AddCategory")Category p){
	//Category p = new Category();
		//p.setCode("1");
		//p.setName("Vallu");
		//p.setPrice("100");
		System.out.println(p);
		pd.addcategory(p);
		ModelAndView modelandview = new ModelAndView("web/admin/category");
		modelandview.addObject("SucessfullMessage", "Sucessfully Added the Category");
		return "redirect:/admin/category";
	}
	
	@RequestMapping("/admin/category")
	public ModelAndView goCategory(){
		//Category p = new Category();
		//p.setCode("2");
		//p.setName("Vallu");
		//p.setPrice("100");
		//pd.addcategory(p);
		List<Category> l=pd.ViewCategory();
		Gson gson = new Gson();
       String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("web/admin/category");
       modelandview.addObject("json",l);
		System.out.println(json);
		return modelandview;
		//return "editcategory";
	}
	@RequestMapping("/admin/editCat/{code}")
	public ModelAndView doeditCategory(@PathVariable int code){
		Category q = pd.viewCategoryby(code);
		ModelAndView modelandview = new ModelAndView("web/admin/category");
		List<Category> l=pd.ViewCategory();
		modelandview.addObject("json",l);
		modelandview.addObject("category",q);
		return modelandview;
	}
	@RequestMapping("/user/category")
	public ModelAndView gocustCategory(){
		//Category p = new Category();
		//p.setCode("2");
		//p.setName("Vallu");
		//p.setPrice("100");
		//pd.addcategory(p);
		List<Category> l=pd.ViewCategory();
		Gson gson = new Gson();
       String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("web/custcategory");
       modelandview.addObject("json",l);
		System.out.println(json);
		return modelandview;
		//return "editcategory";
	}
	@RequestMapping("/admin/delCat")
	public String goDeleteCategory(){
		return "deletecategory";
	}
	@RequestMapping("/admin/delCat/{code}")
	public String doDeleteCategory(@ModelAttribute("AddCategory")Category p){
		pd.deletecategory(p);
		return "redirect:/admin/category";
	}
	@RequestMapping("/web/category")
	public ModelAndView gowebCategory(){
		//Category p = new Category();
		//p.setCode("2");
		//p.setName("Vallu");
		//p.setPrice("100");
		//pd.addcategory(p);
		List<Category> l=pd.ViewCategory();
		Gson gson = new Gson();
       String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("web/category");
       modelandview.addObject("json",l);
		System.out.println(json);
		return modelandview;
		//return "editcategory";
	}
	
}
