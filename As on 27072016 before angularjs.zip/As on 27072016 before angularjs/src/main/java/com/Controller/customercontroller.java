package com.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dao.customerDAO;
import com.google.gson.Gson;
import com.model.Customer;


@Controller
public class customercontroller {
	
	@Autowired
	customerDAO pd;
	
	@ModelAttribute("addcus")
	public Customer douserlogin(){
		return new Customer();
	}
	
	/*@InitBinder
	public void initBinder(WebDataBinder binder){
		binder.setDisallowedFields(new String[]{"Code"});
	}
	@InitBinder
	public void initBinder(WebDataBinder binder) {
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    dateFormat.setLenient(false);
	    binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}
	@RequestMapping("/dologin")
	public ModelAndView douserlogin(@ModelAttribute("userlogin")Customer p, BindingResult br){
		
		return null;
	}*/
	@RequestMapping("/web/addcustomer")
	public String goaddcustomer(@Valid @ModelAttribute("addcus")Customer p, BindingResult br){
	//Category p = new Category();
		//p.setCode("1");
		//p.setName("Vallu");
		//p.setPrice("100");
		ModelAndView modelandview;
		if (br.hasErrors()){
			modelandview= new ModelAndView("web/register");
			
			return "web/register";
		}
		p.setRole("ROLE_USER");
		modelandview= new ModelAndView("web/register");
		pd.addcustomer(p);
		modelandview.addObject("SucessfullMessage", "Sucessfully Added");
		return "redirect:/web/Login";
	}
	
	@RequestMapping("/user/home")
	public String dologin(ModelMap model, Customer user, BindingResult br){
		//Category p = new Category();
		//p.setCode("2");
		//p.setName("Vallu");
		//p.setPrice("100");
		//pd.addcategory(p);
		Customer c = pd.viewcustomerby(user.getUserid());
		//Gson gson = new Gson();
        //String json = gson.toJson(c);
       // ModelAndView modelandview = new ModelAndView("category");
        //modelandview.addObject("json",c);
		//System.out.println(json);
        String userrole =c.getRole(); 
        System.out.println("in UserLogin Controller");
        if(userrole=="ROLE_ADMIN"){
        	return "web/admin";
        }
        return "custindex";
        
		//return "editcategory";
	}
	/*
	@RequestMapping("/editCat/{code}")
	public String doeditCategory(@PathVariable int code){
		Category q = pd.viewCategoryby(code);
		ModelAndView modelandview = new ModelAndView("category");
		modelandview.addObject("category",q);
		return "redirect:/category";
	}
	@RequestMapping("/delCat")
	public String goDeleteCategory(){
		return "deletecategory";
	}
	@RequestMapping("delCat/{code}")
	public String doDeleteCategory(@ModelAttribute("AddCategory")Category p){
		pd.deletecategory(p);
		return "redirect:/category";
	}*/
	@RequestMapping("/web/admin/addcustomer")
	public String doaddadmin(@Valid @ModelAttribute("addcus")Customer p, BindingResult br){
	//Category p = new Category();
		//p.setCode("1");
		//p.setName("Vallu");
		//p.setPrice("100");
		ModelAndView modelandview;
		if (br.hasErrors()){
			modelandview= new ModelAndView("web/admin/adminregister");
			
			return "Register";
		}
		p.setRole("ROLE_ADMIN");
		modelandview= new ModelAndView("web/admin/adminregister");
		pd.addcustomer(p);
		modelandview.addObject("SucessfullMessage", "Sucessfully Added");
		return "/web/admin";
	}
	@RequestMapping("/logout")
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response){
		System.out.println(request.getClass());
		ModelAndView view = new ModelAndView("index");
		request.getSession().invalidate();
		
		return view;
	} 
}
