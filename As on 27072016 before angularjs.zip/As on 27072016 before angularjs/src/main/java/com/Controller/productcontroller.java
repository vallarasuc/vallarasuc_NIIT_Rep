package com.Controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.method.annotation.InitBinderDataBinderFactory;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.dao.ProductDAO;
import com.google.gson.Gson;
import com.model.Products;

@Controller
public class productcontroller {
	
	@Autowired
	ProductDAO pd;
	@ModelAttribute("AddProduct")
	public Products doAddProductview(){
		return new Products();
	}
	
	/*@InitBinder
	public void initBinder(WebDataBinder binder){
		binder.setDisallowedFields(new String[]{"Code"});
	}*/
	@RequestMapping("/admin/addproduct/{path}")
	public String goAddProduct(@ModelAttribute("AddProduct") Products p, BindingResult br, HttpServletRequest request, HttpServletResponse response, @PathVariable String path){
	//Products p = new Products();
		//p.setCode("1");
		//p.setName("Vallu");
		//p.setPrice("100");
		ModelAndView modelandview = new ModelAndView("/web/admin/product");
		if (!p.getFile().isEmpty()) {
            try {
                byte[] bytes = p.getFile().getBytes();
 
                // Creating the directory to store file
               // String rootPath = request.getSession().getServletContext().getRealPath("/");
                File dir = new File("F:\\Eclipse Program2\\Project2v4\\src\\main\\webapp\\resources\\assets"+ File.separator+"tmpFiles");
                if (!dir.exists())
                	
                    dir.mkdirs();
 
                // Create the file on server
                File serverFile = new File(dir.getAbsolutePath()
                        + File.separator + p.getCode()+".jpg");
                BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
                stream.write(bytes);
                stream.close();            
                System.out.println("You successfully uploaded file = F:\\Eclipse Program2\\Project2v4\\src\\main\\webapp\\resources\\assets\\"+p.getCode());
                modelandview.setViewName("index");
            } catch (Exception e) {
                System.out.println("You failed to upload " + p.getCode() + " => " + e.getMessage());
            }
        } 
else {
	modelandview.setViewName("redirect:/admin/product");
            System.out.println("You failed to upload " + p.getCode() + " because the file was empty.");
        }
		
		pd.addproduct(p);
		modelandview.addObject("SucessfullMessage", "Sucessfully Added the Product");
		return "redirect:/admin/product";
	}
	
	@RequestMapping("/admin/product")
	public ModelAndView goProduct(){
		//Products p = new Products();
		//p.setCode("2");
		//p.setName("Vallu");
		//p.setPrice("100");
		//pd.addproduct(p);
		List<Products> l=pd.ViewProducts();
		Gson gson = new Gson();
        String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("/web/admin/product");
        modelandview.addObject("json",l);
		//System.out.println(json);
		return modelandview;
		//return "editproduct";
	}
	@RequestMapping("/admin/product/doedit")
	public ModelAndView doEditProduct(@ModelAttribute("AddProduct") Products p, BindingResult br){
		//Products p = new Products();
		//p.setCode("2");
		//p.setName("Vallu");
		//p.setPrice("100");
		//pd.addproduct(p);
		List<Products> l=pd.ViewProducts();
		Gson gson = new Gson();
        String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("/web/admin/product");
        modelandview.addObject("json",l);
		//System.out.println(json);
		return modelandview;
	}
		//return "editproduct";
	@RequestMapping("/admin/editPrd/{code}")
	public ModelAndView doeditProduct(@PathVariable int code){
		Products q = pd.viewProductsby(code);
		System.out.println(q);
		ModelAndView modelandview = new ModelAndView("/web/admin/product");
		List<Products> l=pd.ViewProducts();
		System.out.println("in list"+l);
		modelandview.addObject("json",l);
		modelandview.addObject("product",q);
		return modelandview;
	}
	@RequestMapping("/delPrd")
	public String goDeleteProduct(){
		return "deleteproduct";
	}
	@RequestMapping("/admin/delPrd/{code}")
	public String doDeleteProduct(@ModelAttribute("AddProduct")Products p){
		pd.deleteproduct(p);
		return "redirect:/admin/product";
	}
	@RequestMapping("/user/product")
	public ModelAndView gocustProduct(){
		//Products p = new Products();
		//p.setCode("2");
		//p.setName("Vallu");
		//p.setPrice("100");
		//pd.addproduct(p);
		List<Products> l=pd.ViewProducts();
		Gson gson = new Gson();
        String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("/web/custproduct");
        modelandview.addObject("json",l);
		//System.out.println(json);
		return modelandview;
		//return "editproduct";
	}
	@RequestMapping("/web/product")
	public ModelAndView goindexProduct(HttpServletRequest request, HttpServletResponse response){
		//Products p = new Products();
		//p.setCode("2");
		//p.setName("Vallu");
		//p.setPrice("100");
		//pd.addproduct(p);
		List<Products> l=pd.ViewProducts();
		List<String> z = new ArrayList<String>();
		//String rootPath = request.getSession().getServletContext().getRealPath("/");
		for(Products x:l)
		{
		
			z.add("/tmpFiles/"+x.getCode()+".jpg");
		}
		Gson gson = new Gson();
        String json = gson.toJson(l);
        String ima = gson.toJson(z);
        ModelAndView modelandview = new ModelAndView("/web/product");
        modelandview.addObject("json",l);
        modelandview.addObject("images",z);
		 //dp.getCode();
		 //System.out.println(pd.getCode());
		//System.out.println(json);
		return modelandview;
	}
	
}
